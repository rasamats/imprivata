﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Imprivata.Startup))]
namespace Imprivata
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
